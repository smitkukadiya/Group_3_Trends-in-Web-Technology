// src/pages/Home.js
import React from 'react';
import '../css/Home.css'; // Import the CSS file
import appleImage from '../images/apple.jpg';
import lycheeImage from '../images/lychee.jpg';
import orangeImage from '../images/orange.jpg';
const Home = () => {
    return (
        <div className="home-container">
            {/* Hero Banner */}
            <section className="hero-banner">
                <div className="overlay">
                    <h1>Welcome to RealFruit</h1>
                    <p>Fresh, Organic, and Delivered Right to Your Door</p>
                    <button className="cta-button">Shop Now</button>
                </div>
            </section>

            {/* Featured Products */}
            <section className="featured-products">
                <h2>Featured Products</h2>
                <div className="products-grid">
                    <div className="product-item">
                        <img src={appleImage} alt="Apple" />
                        <h3>Apple Juice</h3>
                        <p>Only $4.99</p>
                    </div>
                    <div className="product-item">
                        <img src={lycheeImage} alt="Lychee" />
                        <h3>Lychee Juice</h3>
                        <p>Only $3.99</p>
                    </div>
                    <div className="product-item">
                        <img src={orangeImage} alt="Orange" />
                        <h3>Orange Juice</h3>
                        <p>Only $4.49</p>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="footer">
                <p>&copy; 2024 RealFruit. All Rights Reserved.</p>
                <div className="social-media">
                    <a href="#">Facebook</a>
                    <a href="#">Instagram</a>
                    <a href="#">Twitter</a>
                </div>
            </footer>
        </div>
    );
};

export default Home;
