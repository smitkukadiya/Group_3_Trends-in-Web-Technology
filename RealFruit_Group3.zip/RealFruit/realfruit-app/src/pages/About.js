import React from 'react';
import '../css/About.css'; // Import the CSS file

const About = () => {
    return (
        <div className="about-container">
            <section className="about-banner">
                <h1>About RealFruit Juice</h1>
                <p>At RealFruit Juice, we believe in bringing you the best of nature's bounty. Our juices are made from 100% organic fruits, harvested at their peak to ensure maximum flavor and nutrition.</p>
            </section>

            <section className="mission-vision">
                <div className="mission">
                    <h2>Our Mission</h2>
                    <p>To provide our customers with the purest and most delicious fruit juices, free from artificial additives and preservatives. We are committed to sustainability, ensuring that our products are not only good for you but also for the planet.</p>
                </div>
                <div className="vision">
                    <h2>Our Vision</h2>
                    <p>We envision a world where everyone has access to healthy and natural beverages. By supporting local farmers and using eco-friendly packaging, we aim to make this vision a reality.</p>
                </div>
            </section>

            <section className="our-story">
                <h2>Our Story</h2>
                <p>RealFruit Juice was founded with a simple idea: to bring the taste of fresh, organic fruits to everyone. Starting from a small farm, we've grown into a brand that people trust for quality and taste. Our commitment to sustainability and healthy living drives everything we do.</p>
                <p>From our carefully sourced ingredients to our eco-friendly practices, we are dedicated to making a positive impact on the world. Whether you enjoy our juices at home, on the go, or at a special event, you can always taste the difference that passion and quality make.</p>
            </section>

            <section className="our-values">
                <h2>Our Values</h2>
                <ul>
                    <li><strong>Quality:</strong> We use only the finest ingredients to craft our juices.</li>
                    <li><strong>Sustainability:</strong> We are committed to protecting the environment through responsible sourcing and packaging.</li>
                    <li><strong>Community:</strong> We support local farmers and contribute to our communities.</li>
                    <li><strong>Innovation:</strong> We continually explore new ways to bring you the best products.</li>
                </ul>
            </section>

            <section className="call-to-action">
                <h2>Join Us in Our Journey</h2>
                <p>Experience the true taste of nature with RealFruit Juice. Explore our range of delicious and nutritious juices today!</p>
                <button className="cta-button">Shop Now</button>
            </section>
        </div>
    );
};

export default About;
