import React from 'react';
import '../css/Products.css'; // Import the CSS file

const Products = () => {
    const products = [
        {
            id: 1,
            name: "Fresh Apple Juice",
            description: "Crisp, juicy apple juice made from freshly picked apples.",
            price: "$3.99",
            image: "/images/apple.jpg",
        },
        {
            id: 2,
            name: "Organic Lychee Juice",
            description: "Sweet lychee juice with a hint of floral taste. 100% organic.",
            price: "$4.49",
            image: "/images/lychee.jpg",
        },
        {
            id: 3,
            name: "Juicy Orange Juice",
            description: "Refreshing orange juice bursting with natural sweetness.",
            price: "$3.79",
            image: "/images/orange.jpg",
        },
        {
            id: 4,
            name: "Grape Juice",
            description: "Smooth and flavorful grape juice, a great source of antioxidants.",
            price: "$3.59",
            image: "/images/grape.jpg",
        },
        {
            id: 5,
            name: "Sweet Strawberry Juice",
            description: "Rich and sweet strawberry juice, perfect for a refreshing drink.",
            price: "$4.99",
            image: "/images/strawberry.jpg",
        },
        {
            id: 6,
            name: "Fresh Blueberry Juice",
            description: "Blueberry juice packed with antioxidants and natural goodness.",
            price: "$5.49",
            image: "/images/blueberry.jpg",
        },
        {
            id: 7,
            name: "Tropical Kiwi Juice",
            description: "Tangy kiwi juice, ideal for a tropical twist.",
            price: "$4.19",
            image: '/images/kiwi.jpg',
        },
        {
            id: 8,
            name: "Java Plum Juice",
            description: "Unique java plum juice with a rich flavor and antioxidants.",
            price: "$4.89",
            image: '/images/javaplum.jpg',
        },
        {
            id: 9,
            name: "Golden Pineapple Juice",
            description: "Sweet pineapple juice with a tropical delight.",
            price: "$4.29",
            image: '/images/pineapple.jpg',
        },
        {
            id: 10,
            name: "Peach Juice",
            description: "Sweet peach juice, perfect for a refreshing drink.",
            price: "$4.19",
            image: '/images/peach.jpg',
        },
        {
            id: 11,
            name: "Pomegranate Juice",
            description: "Vibrant pomegranate juice, full of flavor and antioxidants.",
            price: "$4.99",
            image: '/images/pomegranate.jpeg',
        },
        {
            id: 12,
            name: "Cherry Juice",
            description: "Sweet cherry juice, ideal for a refreshing treat.",
            price: "$5.49",
            image: '/images/cherry.jpg',
        },
        {
            id: 13,
            name: "Lemon Juice",
            description: "Zesty lemon juice, perfect for adding a citrus kick.",
            price: "$3.49",
            image: '/images/lemon.jpg',
        },
        {
            id: 14,
            name: "Guava Juice",
            description: "Fragrant guava juice, full of tropical flavor.",
            price: "$4.29",
            image: '/images/guava.jpeg',
        },
        {
            id: 15,
            name: "Papaya Juice",
            description: "Sweet papaya juice, a tropical favorite.",
            price: "$4.19",
            image: '/images/papaya.jpg',
        },
        {
            id: 16,
            name: "Mango Juice",
            description: "Juicy mango juice, perfect for smoothies or a refreshing drink.",
            price: "$4.49",
            image: '/images/mango.jpg',
        },
    ];

    return (
        <div className="products-container">
            <h1>Our Products</h1>
            <div className="products-grid">
                {products.map((product) => (
                    <div key={product.id} className="product-card">
                        <img src={product.image} alt={product.name} />
                        <h3>{product.name}</h3>
                        <p>{product.description}</p>
                        <p className="price">{product.price}</p>
                        <button className="add-to-cart">Add to Cart</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Products;
